package enums;

public enum Role {
/**
 * list of available roles
 */
	Manager,
	Waiter,
	Hostess,
	Cashier,
	Cleaner,
	Chef
}
