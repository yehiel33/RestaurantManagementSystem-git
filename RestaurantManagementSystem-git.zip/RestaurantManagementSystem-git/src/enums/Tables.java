package enums;

public enum Tables {
	/**
	 * list of available tables
	 */
	Small_Central,
	Medium_Central,
	Big_Central,
	Bar_1,
	Bar_2,
	Bar_3,
	Upper_Left_Corner,
	Upper_Right_Corner,
	Lower_Left_Corner,
	Lower_Right_Corner
}
