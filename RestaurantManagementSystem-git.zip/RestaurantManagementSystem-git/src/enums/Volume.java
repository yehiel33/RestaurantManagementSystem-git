package enums;

public enum Volume {

	One_Third_Of_A_Liter,
	Half_A_Litr,
	Liter,
	A_Liter_And_a_Half;
}
